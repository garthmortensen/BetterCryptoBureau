package com.example.springthymeredis.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MyController {
	// TODO: what does @GetMapping annotation do?
	@GetMapping("/greeting")
	// TODO: fix next line to match our actual Model data. Some of these variables need updating. There is no "name" as far as i know
	public String greeting(@RequestParam(name="name", required=false, defaultValue="World") String name, Model model) {
		model.addAttribute("name", "Mike");
		return "greeting";
		}
}
