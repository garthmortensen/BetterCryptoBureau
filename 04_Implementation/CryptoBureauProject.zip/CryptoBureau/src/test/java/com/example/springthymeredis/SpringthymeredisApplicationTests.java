package com.example.springthymeredis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringthymeredisApplicationTests {

	@Test
	void contextLoads() {
	}

}
